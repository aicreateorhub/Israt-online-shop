
export type Category = 'Shirts' | 'Pants' | 'Panjabi' | 'Suits' | 'Accessories';

export interface Product {
  id: string;
  name: string;
  category: Category;
  mrp: number;
  price: number;
  stock: number;
  images: string[];
  description: string;
  sizes: string[];
  colors: string[];
  isFeatured?: boolean;
  reviews: Review[];
}

export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
  images?: string[];
}

export interface CartItem extends Product {
  selectedSize: string;
  selectedColor: string;
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  status: 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Canceled';
  date: string;
  customer: {
    name: string;
    phone: string;
    address: string;
    area: 'Inside Dhaka' | 'Outside Dhaka';
  };
  paymentMethod: 'COD' | 'bKash' | 'Nagad' | 'Card';
}

export interface PromoCode {
  code: string;
  discountType: 'Percentage' | 'Fixed';
  value: number;
  expiryDate: string;
}


import { Product, PromoCode } from './types';

export const COLORS = {
  primary: '#0F172A', // Slate 900
  accent: '#B45309',  // Amber 700
  secondary: '#64748B', // Slate 500
};

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Premium Oxford Cotton Shirt',
    category: 'Shirts',
    mrp: 2450,
    price: 1850,
    stock: 12,
    images: [
      'https://picsum.photos/seed/shirt1/800/1000',
      'https://picsum.photos/seed/shirt1_2/800/1000'
    ],
    description: 'Our signature Oxford shirt is crafted from 100% premium cotton for a breathable, comfortable fit. Perfect for formal and casual occasions.',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['White', 'Light Blue', 'Pink'],
    isFeatured: true,
    reviews: [
      { id: 'r1', userName: 'Asif Rahman', rating: 5, comment: 'Excellent quality! The fabric feels premium.', date: '2023-10-15' }
    ]
  },
  {
    id: '2',
    name: 'Slim Fit Chino Pants',
    category: 'Pants',
    mrp: 1950,
    price: 1450,
    stock: 4,
    images: [
      'https://picsum.photos/seed/pants1/800/1000',
      'https://picsum.photos/seed/pants1_2/800/1000'
    ],
    description: 'Tapered slim-fit chinos made with stretch twill fabric. Versatile for office and weekends.',
    sizes: ['30', '32', '34', '36'],
    colors: ['Beige', 'Navy', 'Olive'],
    isFeatured: true,
    reviews: []
  },
  {
    id: '3',
    name: 'Royal Heritage Panjabi',
    category: 'Panjabi',
    mrp: 4500,
    price: 3800,
    stock: 15,
    images: [
      'https://picsum.photos/seed/panjabi1/800/1000',
    ],
    description: 'Elegant semi-formal Panjabi with intricate embroidery around the neck and cuffs.',
    sizes: ['40', '42', '44'],
    colors: ['Royal Blue', 'Deep Maroon'],
    isFeatured: true,
    reviews: []
  },
  {
    id: '4',
    name: 'Italian Wool Three-Piece Suit',
    category: 'Suits',
    mrp: 15500,
    price: 12500,
    stock: 3,
    images: [
      'https://picsum.photos/seed/suit1/800/1000',
    ],
    description: 'Meticulously tailored three-piece suit featuring high-quality Italian wool blend.',
    sizes: ['48', '50', '52'],
    colors: ['Charcoal', 'Midnight Black'],
    reviews: []
  }
];

export const MOCK_PROMOS: PromoCode[] = [
  { code: 'ELITE10', discountType: 'Percentage', value: 10, expiryDate: '2025-12-31' },
  { code: 'SAVE500', discountType: 'Fixed', value: 500, expiryDate: '2025-12-31' },
];

export const SHIPPING_RATES = {
  INSIDE_DHAKA: 60,
  OUTSIDE_DHAKA: 120
};

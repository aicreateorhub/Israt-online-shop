
import React from 'react';
import { MOCK_PRODUCTS } from '../constants';
import ProductCard from '../components/ProductCard';
import { Product } from '../types';
import { ArrowRight, ChevronRight, Truck, ShieldCheck, RefreshCw, MessageSquare } from 'lucide-react';

interface HomeProps {
  onViewProduct: (id: string) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (id: string) => void;
  wishlist: string[];
}

const Home: React.FC<HomeProps> = ({ onViewProduct, onAddToCart, onToggleWishlist, wishlist }) => {
  const featured = MOCK_PRODUCTS.filter(p => p.isFeatured);

  return (
    <div className="space-y-12 pb-20">
      {/* Hero Banner */}
      <section className="relative h-[70vh] w-full overflow-hidden">
        <img 
          src="https://picsum.photos/seed/fashion_hero/1600/900" 
          alt="Hero" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/30 flex flex-col items-center justify-center text-center p-4">
          <h2 className="text-white text-xs font-bold uppercase tracking-[0.3em] mb-4">New Season Arrival</h2>
          <h1 className="text-white text-5xl md:text-7xl font-bold mb-8">ELEGANCE REDEFINED</h1>
          <button className="bg-white text-slate-900 px-8 py-4 text-sm font-bold tracking-widest hover:bg-amber-700 hover:text-white transition-colors duration-300">
            SHOP THE COLLECTION
          </button>
        </div>
      </section>

      {/* Feature Icons */}
      <section className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: <Truck />, title: 'Fast Delivery', desc: 'Across Bangladesh' },
          { icon: <ShieldCheck />, title: 'Premium Quality', desc: '100% Original' },
          { icon: <RefreshCw />, title: 'Easy Returns', desc: '7-Day Policy' },
          { icon: <MessageSquare />, title: '24/7 Support', desc: 'Dedicated Team' },
        ].map((item, i) => (
          <div key={i} className="flex flex-col items-center text-center p-6 bg-white border border-gray-100 rounded-lg hover:shadow-sm transition-shadow">
            <div className="text-amber-700 mb-3">{item.icon}</div>
            <h3 className="font-bold text-sm text-slate-900">{item.title}</h3>
            <p className="text-xs text-gray-500">{item.desc}</p>
          </div>
        ))}
      </section>

      {/* Categories Grid */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-bold text-slate-900">Explore Categories</h2>
            <div className="h-1 w-12 bg-amber-700 mt-2"></div>
          </div>
          <button className="text-sm font-bold flex items-center space-x-1 text-amber-700 hover:underline">
            <span>VIEW ALL</span> <ChevronRight size={16} />
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <CategoryTile title="Elegance Shirts" img="https://picsum.photos/seed/cat_shirt/600/800" />
          <CategoryTile title="Signature Panjabi" img="https://picsum.photos/seed/cat_panjabi/600/800" />
          <CategoryTile title="Premium Trousers" img="https://picsum.photos/seed/cat_pants/600/800" />
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-bold text-slate-900">Staff Picks</h2>
            <p className="text-gray-500 mt-1">Our best-selling essentials for your wardrobe.</p>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {featured.map(product => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onView={onViewProduct}
              onAddToCart={onAddToCart}
              onToggleWishlist={onToggleWishlist}
              isWishlisted={wishlist.includes(product.id)}
            />
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-slate-900 py-20 px-4">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <h2 className="text-white text-3xl md:text-5xl font-bold">Join the Elite Club</h2>
          <p className="text-slate-400">Get early access to drops and exclusive discounts delivered to your inbox.</p>
          <div className="flex max-w-md mx-auto">
            <input 
              type="email" 
              placeholder="Your email address" 
              className="flex-1 px-4 py-3 bg-white/10 border border-slate-700 text-white outline-none focus:border-amber-700 rounded-l"
            />
            <button className="bg-amber-700 text-white px-6 py-3 font-bold rounded-r">SUBSCRIBE</button>
          </div>
        </div>
      </section>

      {/* Messenger/WhatsApp Fixed Support */}
      <div className="fixed bottom-6 right-6 z-40 space-y-4">
        <a 
          href="https://wa.me/8801XXXXXXXXX" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center justify-center w-14 h-14 bg-green-500 text-white rounded-full shadow-2xl hover:scale-110 transition-transform"
        >
          <MessageSquare size={24} />
        </a>
      </div>
    </div>
  );
};

const CategoryTile = ({ title, img }: { title: string; img: string }) => (
  <div className="group relative h-96 overflow-hidden rounded-xl cursor-pointer">
    <img src={img} alt={title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-8">
      <h3 className="text-white text-2xl font-bold mb-4">{title}</h3>
      <div className="flex items-center text-white text-xs font-bold tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
        SHOP NOW <ArrowRight size={14} className="ml-2" />
      </div>
    </div>
  </div>
);

export default Home;

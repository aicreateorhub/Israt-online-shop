
import React, { useState } from 'react';
import { Product, CartItem } from '../types';
import { Heart, ShoppingBag, Truck, ShieldCheck, ChevronLeft, ChevronRight, Star } from 'lucide-react';

interface ProductDetailProps {
  product: Product;
  onAddToCart: (item: CartItem) => void;
  onBack: () => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product, onAddToCart, onBack }) => {
  const [activeImg, setActiveImg] = useState(0);
  const [selectedSize, setSelectedSize] = useState(product.sizes[0]);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);
  const [qty, setQty] = useState(1);

  const handleAdd = () => {
    onAddToCart({
      ...product,
      selectedSize,
      selectedColor,
      quantity: qty
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button 
        onClick={onBack}
        className="mb-6 flex items-center text-sm text-gray-500 hover:text-amber-700"
      >
        <ChevronLeft size={16} /> BACK TO SHOP
      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Gallery */}
        <div className="space-y-4">
          <div className="aspect-[4/5] bg-gray-100 rounded-xl overflow-hidden relative group">
            <img 
              src={product.images[activeImg]} 
              alt={product.name} 
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-150 cursor-crosshair"
            />
            {product.images.length > 1 && (
              <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-4 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={() => setActiveImg(prev => (prev > 0 ? prev - 1 : product.images.length - 1))}
                  className="bg-white/80 p-2 rounded-full shadow-sm"
                >
                  <ChevronLeft size={20} />
                </button>
                <button 
                  onClick={() => setActiveImg(prev => (prev < product.images.length - 1 ? prev + 1 : 0))}
                  className="bg-white/80 p-2 rounded-full shadow-sm"
                >
                  <ChevronRight size={20} />
                </button>
              </div>
            )}
          </div>
          <div className="flex space-x-4 overflow-x-auto pb-2 no-scrollbar">
            {product.images.map((img, i) => (
              <button 
                key={i} 
                onClick={() => setActiveImg(i)}
                className={`w-20 h-24 flex-shrink-0 border-2 rounded-md overflow-hidden ${activeImg === i ? 'border-amber-700' : 'border-transparent'}`}
              >
                <img src={img} alt="thumb" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="space-y-6">
          <div>
            <h4 className="text-amber-700 text-xs font-bold uppercase tracking-widest">{product.category}</h4>
            <h1 className="text-3xl font-bold text-slate-900 mt-2">{product.name}</h1>
            <div className="flex items-center mt-3 space-x-2">
              <div className="flex text-amber-500">
                {[...Array(5)].map((_, i) => <Star key={i} size={16} fill={i < 4 ? "currentColor" : "none"} />)}
              </div>
              <span className="text-sm text-gray-500">(12 Reviews)</span>
            </div>
          </div>

          <div className="flex items-end space-x-3">
            <span className="text-3xl font-bold text-slate-900">৳{product.price}</span>
            {product.mrp > product.price && (
              <span className="text-lg text-gray-400 line-through mb-1">৳{product.mrp}</span>
            )}
            {product.mrp > product.price && (
              <span className="bg-amber-100 text-amber-700 text-xs font-bold px-2 py-1 rounded mb-1">
                {Math.round(((product.mrp - product.price) / product.mrp) * 100)}% OFF
              </span>
            )}
          </div>

          <p className="text-gray-600 leading-relaxed">{product.description}</p>

          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-bold mb-3">SELECT SIZE</h4>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map(size => (
                  <button 
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`min-w-[48px] h-10 border text-sm font-medium rounded transition-colors ${selectedSize === size ? 'border-slate-900 bg-slate-900 text-white' : 'border-gray-200 hover:border-amber-700'}`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-bold mb-3">SELECT COLOR</h4>
              <div className="flex flex-wrap gap-3">
                {product.colors.map(color => (
                  <button 
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`px-4 py-2 border text-xs font-bold uppercase tracking-wider rounded transition-colors ${selectedColor === color ? 'border-slate-900 bg-slate-900 text-white' : 'border-gray-200 hover:border-amber-700'}`}
                  >
                    {color}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-4 pt-4">
              <div className="flex items-center border border-gray-200 rounded">
                <button onClick={() => setQty(q => Math.max(1, q-1))} className="px-3 py-2 hover:bg-gray-100">-</button>
                <span className="w-10 text-center font-medium">{qty}</span>
                <button onClick={() => setQty(q => q+1)} className="px-3 py-2 hover:bg-gray-100">+</button>
              </div>
              <button 
                onClick={handleAdd}
                className="flex-1 bg-slate-900 text-white font-bold py-3 px-8 rounded flex items-center justify-center space-x-2 hover:bg-slate-800 transition-colors"
              >
                <ShoppingBag size={20} />
                <span>ADD TO BAG</span>
              </button>
              <button className="p-3 border border-gray-200 rounded hover:border-red-500 hover:text-red-500 transition-colors">
                <Heart size={20} />
              </button>
            </div>
            
            {product.stock <= 5 && (
              <p className="text-amber-700 text-sm font-semibold italic flex items-center">
                ⚠️ Only {product.stock} items left in stock!
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4 pt-6 border-t border-gray-100">
            <div className="flex items-center space-x-3 text-sm text-gray-600">
              <Truck size={18} className="text-amber-700" />
              <span>Standard delivery in 2-4 days</span>
            </div>
            <div className="flex items-center space-x-3 text-sm text-gray-600">
              <ShieldCheck size={18} className="text-amber-700" />
              <span>100% Cotton Premium Fabric</span>
            </div>
          </div>
        </div>
      </div>

      {/* Review Section */}
      <section className="mt-20">
        <h2 className="text-2xl font-bold mb-8">Customer Reviews</h2>
        {product.reviews.length > 0 ? (
          <div className="space-y-8 max-w-3xl">
            {product.reviews.map(review => (
              <div key={review.id} className="border-b border-gray-100 pb-8">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold">{review.userName}</h4>
                  <span className="text-xs text-gray-400">{review.date}</span>
                </div>
                <div className="flex text-amber-500 mb-3">
                  {[...Array(5)].map((_, i) => <Star key={i} size={14} fill={i < review.rating ? "currentColor" : "none"} />)}
                </div>
                <p className="text-gray-600 italic text-sm">"{review.comment}"</p>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-gray-50 rounded-lg">
            <p className="text-gray-500">No reviews yet. Be the first to review this product!</p>
            <button className="mt-4 text-amber-700 font-bold">Write a review</button>
          </div>
        )}
      </section>
    </div>
  );
};

export default ProductDetail;


import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { ShoppingCart, Users, DollarSign, Package, TrendingUp, AlertCircle } from 'lucide-react';

const data = [
  { name: 'Mon', sales: 4000 },
  { name: 'Tue', sales: 3000 },
  { name: 'Wed', sales: 2000 },
  { name: 'Thu', sales: 2780 },
  { name: 'Fri', sales: 1890 },
  { name: 'Sat', sales: 2390 },
  { name: 'Sun', sales: 3490 },
];

const AdminDashboard: React.FC = () => {
  return (
    <div className="p-6 space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Admin Overview</h1>
        <p className="text-gray-500">Real-time stats for Elite Apparel BD</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard icon={<DollarSign />} label="Total Revenue" value="৳128,450" change="+12.5%" positive />
        <StatCard icon={<ShoppingCart />} label="Orders Today" value="48" change="+8.2%" positive />
        <StatCard icon={<Users />} label="New Customers" value="12" change="-2.1%" positive={false} />
        <StatCard icon={<Package />} label="Low Stock Items" value="03" subValue="Requires attention" warning />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Sales Chart */}
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <h3 className="font-bold mb-6 flex items-center justify-between">
            <span>Weekly Sales Performance</span>
            <TrendingUp size={18} className="text-green-500" />
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <Tooltip 
                  cursor={{ fill: '#F8FAFC' }}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="sales" fill="#0F172A" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <h3 className="font-bold mb-6">Pending Orders</h3>
          <div className="space-y-4">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center border border-gray-200">
                    <ShoppingCart size={16} className="text-slate-500" />
                  </div>
                  <div>
                    <p className="text-sm font-bold">Order #ORD-2023-00{i}</p>
                    <p className="text-xs text-gray-500">2 items • ৳{Math.floor(Math.random() * 5000) + 1000}</p>
                  </div>
                </div>
                <span className="text-[10px] font-bold px-2 py-1 bg-amber-100 text-amber-700 rounded-full">PENDING</span>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 text-sm font-bold text-amber-700 hover:underline">VIEW ALL ORDERS</button>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon, label, value, change, positive, subValue, warning }: any) => (
  <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
    <div className="flex justify-between items-start">
      <div className={`p-3 rounded-lg ${warning ? 'bg-red-50 text-red-600' : 'bg-slate-50 text-slate-600'}`}>
        {icon}
      </div>
      {change && (
        <span className={`text-xs font-bold px-2 py-1 rounded-full ${positive ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
          {change}
        </span>
      )}
    </div>
    <div className="mt-4">
      <p className="text-sm text-gray-500">{label}</p>
      <h4 className="text-2xl font-bold text-slate-900">{value}</h4>
      {subValue && <p className="text-[10px] font-medium text-red-500 mt-1 uppercase tracking-tighter flex items-center"><AlertCircle size={10} className="mr-1" /> {subValue}</p>}
    </div>
  </div>
);

export default AdminDashboard;

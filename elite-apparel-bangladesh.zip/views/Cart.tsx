
import React, { useState } from 'react';
import { CartItem, PromoCode } from '../types';
import { Trash2, ArrowRight, ShieldCheck, Truck, ShoppingBag } from 'lucide-react';
import { MOCK_PROMOS, SHIPPING_RATES } from '../constants';

interface CartProps {
  items: CartItem[];
  onUpdateQty: (id: string, qty: number, size: string, color: string) => void;
  onRemove: (id: string, size: string, color: string) => void;
  onNext: (summary: any) => void;
}

const Cart: React.FC<CartProps> = ({ items, onUpdateQty, onRemove, onNext }) => {
  const [promoInput, setPromoInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);
  const [area, setArea] = useState<'Inside Dhaka' | 'Outside Dhaka'>('Inside Dhaka');

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = appliedPromo 
    ? (appliedPromo.discountType === 'Percentage' ? (subtotal * appliedPromo.value / 100) : appliedPromo.value)
    : 0;
  const shipping = items.length > 0 ? (area === 'Inside Dhaka' ? SHIPPING_RATES.INSIDE_DHAKA : SHIPPING_RATES.OUTSIDE_DHAKA) : 0;
  const total = subtotal - discount + shipping;

  const handleApplyPromo = () => {
    const promo = MOCK_PROMOS.find(p => p.code.toUpperCase() === promoInput.toUpperCase());
    if (promo) {
      setAppliedPromo(promo);
    } else {
      alert('Invalid promo code');
    }
  };

  if (items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-gray-100 rounded-full text-gray-400 mb-6">
          <ShoppingBag size={32} />
        </div>
        <h2 className="text-2xl font-bold mb-2">Your Bag is Empty</h2>
        <p className="text-gray-500 mb-8">Looks like you haven't added anything to your cart yet.</p>
        <button className="bg-slate-900 text-white px-8 py-3 rounded font-bold">CONTINUE SHOPPING</button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-10">Shopping Bag</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Items List */}
        <div className="lg:col-span-2 space-y-6">
          {items.map((item, idx) => (
            <div key={`${item.id}-${item.selectedSize}-${item.selectedColor}`} className="flex space-x-6 pb-6 border-b border-gray-100">
              <div className="w-24 h-32 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 flex flex-col">
                <div className="flex justify-between">
                  <div>
                    <h3 className="font-bold text-slate-900">{item.name}</h3>
                    <p className="text-xs text-gray-500 mt-1">Size: {item.selectedSize} | Color: {item.selectedColor}</p>
                  </div>
                  <button 
                    onClick={() => onRemove(item.id, item.selectedSize, item.selectedColor)}
                    className="text-gray-400 hover:text-red-500"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
                <div className="flex justify-between items-end mt-auto">
                  <div className="flex items-center border border-gray-200 rounded">
                    <button 
                      onClick={() => onUpdateQty(item.id, item.quantity - 1, item.selectedSize, item.selectedColor)}
                      className="px-2 py-1 hover:bg-gray-100"
                    >-</button>
                    <span className="w-8 text-center text-sm">{item.quantity}</span>
                    <button 
                      onClick={() => onUpdateQty(item.id, item.quantity + 1, item.selectedSize, item.selectedColor)}
                      className="px-2 py-1 hover:bg-gray-100"
                    >+</button>
                  </div>
                  <div className="text-right">
                    <span className="block font-bold">৳{item.price * item.quantity}</span>
                    {item.quantity > 1 && <span className="text-xs text-gray-400">৳{item.price} each</span>}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm space-y-4">
            <h2 className="text-lg font-bold">Order Summary</h2>
            
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>৳{subtotal}</span>
              </div>
              
              <div className="pt-2">
                <p className="text-xs text-gray-500 mb-2">Apply Promo Code</p>
                <div className="flex">
                  <input 
                    type="text" 
                    value={promoInput}
                    onChange={(e) => setPromoInput(e.target.value)}
                    placeholder="ENTER CODE" 
                    className="flex-1 border border-gray-200 rounded-l px-3 py-2 text-xs outline-none focus:border-amber-700"
                  />
                  <button 
                    onClick={handleApplyPromo}
                    className="bg-slate-900 text-white px-4 py-2 text-xs font-bold rounded-r"
                  >APPLY</button>
                </div>
                {appliedPromo && (
                  <p className="text-[10px] text-green-600 font-bold mt-1 uppercase">Promo Applied: {appliedPromo.code} (-৳{discount})</p>
                )}
              </div>

              <div className="pt-2">
                <p className="text-xs text-gray-500 mb-2">Delivery Location</p>
                <select 
                  value={area} 
                  onChange={(e) => setArea(e.target.value as any)}
                  className="w-full border border-gray-200 rounded px-3 py-2 text-xs outline-none focus:border-amber-700"
                >
                  <option value="Inside Dhaka">Inside Dhaka (+৳60)</option>
                  <option value="Outside Dhaka">Outside Dhaka (+৳120)</option>
                </select>
              </div>

              <div className="flex justify-between text-gray-600 pt-2">
                <span>Shipping</span>
                <span>৳{shipping}</span>
              </div>

              {discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Promo Discount</span>
                  <span>-৳{discount}</span>
                </div>
              )}

              <div className="flex justify-between text-lg font-bold text-slate-900 pt-4 border-t border-gray-100">
                <span>Total</span>
                <span>৳{total}</span>
              </div>
            </div>

            <button 
              onClick={() => onNext({ subtotal, discount, shipping, total, area })}
              className="w-full bg-slate-900 text-white font-bold py-4 rounded-lg flex items-center justify-center space-x-2 group"
            >
              <span>CHECKOUT NOW</span>
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-3 text-xs text-gray-500">
              <ShieldCheck size={16} className="text-green-600" />
              <span>Secure Payment Gateway Integrated</span>
            </div>
            <div className="flex items-center space-x-3 text-xs text-gray-500">
              <Truck size={16} className="text-amber-700" />
              <span>Free Delivery on orders above ৳5000</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;


import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Home from './views/Home';
import ProductDetail from './views/ProductDetail';
import Cart from './views/Cart';
import AdminDashboard from './views/AdminDashboard';
import { Product, CartItem, Category } from './types';
import { MOCK_PRODUCTS } from './constants';

type View = 'home' | 'shop' | 'product' | 'cart' | 'wishlist' | 'profile' | 'categories' | 'admin-dashboard' | 'checkout-address' | 'checkout-payment';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [isAdmin, setIsAdmin] = useState(true); // Default to true for demo purposes

  const handleNavigate = (view: string) => {
    setCurrentView(view as View);
    window.scrollTo(0, 0);
  };

  const handleViewProduct = (id: string) => {
    setSelectedProductId(id);
    setCurrentView('product');
    window.scrollTo(0, 0);
  };

  const handleAddToCart = (product: Product | CartItem) => {
    setCart(prev => {
      // If it's a generic product from Home/Shop, use defaults
      const isFullCartItem = 'selectedSize' in product;
      const size = isFullCartItem ? (product as CartItem).selectedSize : product.sizes[0];
      const color = isFullCartItem ? (product as CartItem).selectedColor : product.colors[0];
      const qty = isFullCartItem ? (product as CartItem).quantity : 1;

      const existing = prev.find(item => item.id === product.id && item.selectedSize === size && item.selectedColor === color);
      if (existing) {
        return prev.map(item => 
          (item.id === product.id && item.selectedSize === size && item.selectedColor === color)
            ? { ...item, quantity: item.quantity + qty }
            : item
        );
      }
      return [...prev, { ...product, selectedSize: size, selectedColor: color, quantity: qty } as CartItem];
    });
    // Optional: show toast or navigate to cart
    setCurrentView('cart');
  };

  const updateCartQty = (id: string, qty: number, size: string, color: string) => {
    if (qty < 1) return;
    setCart(prev => prev.map(item => 
      (item.id === id && item.selectedSize === size && item.selectedColor === color)
        ? { ...item, quantity: qty }
        : item
    ));
  };

  const removeFromCart = (id: string, size: string, color: string) => {
    setCart(prev => prev.filter(item => !(item.id === id && item.selectedSize === size && item.selectedColor === color)));
  };

  const toggleWishlist = (id: string) => {
    setWishlist(prev => prev.includes(id) ? prev.filter(wid => wid !== id) : [...prev, id]);
  };

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return (
          <Home 
            onViewProduct={handleViewProduct} 
            onAddToCart={handleAddToCart}
            onToggleWishlist={toggleWishlist}
            wishlist={wishlist}
          />
        );
      case 'product':
        const prod = MOCK_PRODUCTS.find(p => p.id === selectedProductId);
        return prod ? <ProductDetail product={prod} onAddToCart={handleAddToCart} onBack={() => setCurrentView('home')} /> : <div>Product not found</div>;
      case 'cart':
        return <Cart items={cart} onUpdateQty={updateCartQty} onRemove={removeFromCart} onNext={() => alert('Proceeding to Address (Checkout Step 2)')} />;
      case 'admin-dashboard':
        return <AdminDashboard />;
      default:
        return <div className="p-20 text-center">View coming soon: {currentView}</div>;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar cartCount={cart.reduce((s, i) => s + i.quantity, 0)} onNavigate={handleNavigate} isAdmin={isAdmin} />
      
      <main className="flex-1">
        {renderView()}
      </main>

      <footer className="bg-slate-900 text-slate-400 py-12 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h2 className="text-white text-2xl font-bold tracking-tighter">ELITE<span className="text-amber-700">.</span></h2>
            <p className="text-sm">Premium apparel for the modern lifestyle in Bangladesh. Quality you can trust, elegance you can wear.</p>
          </div>
          <div>
            <h3 className="text-white font-bold mb-4">SHOP</h3>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => handleNavigate('shop')}>All Products</button></li>
              <li><button>Shirts Collection</button></li>
              <li><button>Panjabi Selection</button></li>
              <li><button>Premium Suits</button></li>
            </ul>
          </div>
          <div>
            <h3 className="text-white font-bold mb-4">SUPPORT</h3>
            <ul className="space-y-2 text-sm">
              <li><button>Contact Us</button></li>
              <li><button>Shipping Policy</button></li>
              <li><button>Returns & Exchanges</button></li>
              <li><button>Track Your Order</button></li>
            </ul>
          </div>
          <div>
            <h3 className="text-white font-bold mb-4">FOLLOW US</h3>
            <div className="flex space-x-4">
               {/* Icon Placeholders */}
               <span className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center hover:bg-amber-700 transition-colors cursor-pointer">FB</span>
               <span className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center hover:bg-amber-700 transition-colors cursor-pointer">IG</span>
               <span className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center hover:bg-amber-700 transition-colors cursor-pointer">TW</span>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto border-t border-slate-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center text-xs">
          <p>© 2024 Elite Apparel BD. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
             <img src="https://img.icons8.com/color/48/visa.png" className="h-6 grayscale hover:grayscale-0" alt="Visa" />
             <img src="https://img.icons8.com/color/48/mastercard.png" className="h-6 grayscale hover:grayscale-0" alt="MC" />
             <img src="https://img.icons8.com/color/48/bkash.png" className="h-6 grayscale hover:grayscale-0" alt="bKash" />
             <img src="https://img.icons8.com/color/48/nagad.png" className="h-6 grayscale hover:grayscale-0" alt="Nagad" />
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;


import React from 'react';
import { Product } from '../types';
import { Heart, ShoppingBag } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onView: (id: string) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (id: string) => void;
  isWishlisted?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onView, onAddToCart, onToggleWishlist, isWishlisted }) => {
  const discount = Math.round(((product.mrp - product.price) / product.mrp) * 100);

  return (
    <div className="group relative bg-white">
      <div className="aspect-[4/5] w-full overflow-hidden rounded-lg bg-gray-200 relative">
        <img
          src={product.images[0]}
          alt={product.name}
          className="h-full w-full object-cover object-center group-hover:scale-105 transition-transform duration-500 cursor-pointer"
          onClick={() => onView(product.id)}
        />
        {discount > 0 && (
          <span className="absolute top-3 left-3 bg-amber-700 text-white text-[10px] font-bold px-2 py-1 rounded">
            {discount}% OFF
          </span>
        )}
        <button 
          onClick={() => onToggleWishlist(product.id)}
          className={`absolute top-3 right-3 p-2 rounded-full shadow-sm bg-white/80 backdrop-blur-sm transition-colors ${isWishlisted ? 'text-red-500' : 'text-gray-400 hover:text-red-500'}`}
        >
          <Heart size={18} fill={isWishlisted ? "currentColor" : "none"} />
        </button>

        {/* Quick Add Overlay */}
        <div className="absolute bottom-4 left-4 right-4 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all">
          <button 
            onClick={() => onAddToCart(product)}
            className="w-full bg-slate-900 text-white text-sm font-bold py-3 flex items-center justify-center space-x-2 rounded shadow-xl"
          >
            <ShoppingBag size={16} />
            <span>QUICK ADD</span>
          </button>
        </div>
      </div>
      
      <div className="mt-4 space-y-1 px-1">
        <h3 className="text-xs text-gray-500 uppercase tracking-widest">{product.category}</h3>
        <h2 
          className="text-sm font-medium text-gray-900 truncate cursor-pointer hover:text-amber-700"
          onClick={() => onView(product.id)}
        >
          {product.name}
        </h2>
        <div className="flex items-center space-x-2">
          <span className="text-base font-bold text-gray-900">৳{product.price}</span>
          {product.mrp > product.price && (
            <span className="text-xs text-gray-400 line-through">৳{product.mrp}</span>
          )}
        </div>
        {product.stock <= 5 && product.stock > 0 && (
          <p className="text-[10px] text-amber-600 font-semibold uppercase tracking-tighter italic">Only {product.stock} left!</p>
        )}
      </div>
    </div>
  );
};

export default ProductCard;

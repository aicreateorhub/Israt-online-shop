
import React, { useState } from 'react';
import { Search, ShoppingBag, Heart, Menu, X, User } from 'lucide-react';

interface NavbarProps {
  cartCount: number;
  onNavigate: (view: string) => void;
  isAdmin?: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ cartCount, onNavigate, isAdmin }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div 
            className="flex-shrink-0 flex items-center cursor-pointer"
            onClick={() => onNavigate('home')}
          >
            <span className="text-2xl font-bold tracking-tighter text-slate-900">ELITE<span className="text-amber-700">.</span></span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex space-x-8">
            <button onClick={() => onNavigate('shop')} className="text-sm font-medium text-gray-700 hover:text-amber-700">SHOP</button>
            <button onClick={() => onNavigate('categories')} className="text-sm font-medium text-gray-700 hover:text-amber-700">CATEGORIES</button>
            <button className="text-sm font-medium text-gray-700 hover:text-amber-700">NEW ARRIVALS</button>
            {isAdmin && <button onClick={() => onNavigate('admin-dashboard')} className="text-sm font-bold text-amber-700">ADMIN PANEL</button>}
          </div>

          {/* Icons */}
          <div className="flex items-center space-x-4">
            <button className="p-2 text-gray-500 hover:text-amber-700">
              <Search size={20} />
            </button>
            <button 
              onClick={() => onNavigate('wishlist')}
              className="hidden sm:block p-2 text-gray-500 hover:text-amber-700"
            >
              <Heart size={20} />
            </button>
            <button 
              onClick={() => onNavigate('cart')}
              className="p-2 text-gray-500 hover:text-amber-700 relative"
            >
              <ShoppingBag size={20} />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 h-4 w-4 bg-amber-700 text-white text-[10px] flex items-center justify-center rounded-full">
                  {cartCount}
                </span>
              )}
            </button>
            <button 
               onClick={() => onNavigate('profile')}
               className="hidden sm:block p-2 text-gray-500 hover:text-amber-700"
            >
              <User size={20} />
            </button>
            <button 
              className="md:hidden p-2 text-gray-500"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-b border-gray-100 py-4 px-4 space-y-4">
          <button onClick={() => { onNavigate('shop'); setIsMenuOpen(false); }} className="block w-full text-left font-medium">Shop All</button>
          <button onClick={() => { onNavigate('categories'); setIsMenuOpen(false); }} className="block w-full text-left font-medium">Categories</button>
          <button onClick={() => { onNavigate('profile'); setIsMenuOpen(false); }} className="block w-full text-left font-medium">My Profile</button>
          <button onClick={() => { onNavigate('wishlist'); setIsMenuOpen(false); }} className="block w-full text-left font-medium">Wishlist</button>
          {isAdmin && <button onClick={() => { onNavigate('admin-dashboard'); setIsMenuOpen(false); }} className="block w-full text-left font-bold text-amber-700">Admin Dashboard</button>}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
